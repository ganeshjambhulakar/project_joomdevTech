<?php

namespace App\Http\Controllers;

use App\Models\Patien;
use App\Models\Hospital;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PatienController extends Controller
{
    public function index()
    {
        $data = DB::table('patients')
            ->select('patients.*', 'hospitals.hospital_name', 'departments.department_name')
            ->join('departments', 'departments.department_id', "=", "patients.department_id")
            ->join('hospitals', 'hospitals.hospital_id', "=", "patients.hospital_id")
            ->get();       //Fetch all patient record
        return view('list', compact('data', $data));
    }
    public function search(Request $req)
    {
        // Check Which input field is to be search
        if ($req->post('phone') != "" && $req->post('email') != "") {
            $query = "patients.phone='{$req->post('phone')}' and patients.email='{$req->post('email')}'"; //If email and phone are input
        } elseif ($req->post('phone') != "") {
            $query = "patients.phone='{$req->post('phone')}'"; // if only phone is inputed
        } elseif ($req->post('email') != "") {
            $query = "patients.email='{$req->post('email')}'"; //if only email is inputed
        }
        $data = DB::select(DB::raw("SELECT * FROM patients,departments,hospitals WHERE (departments.department_id=patients.department_id and hospitals.hospital_id=patients.hospital_id) and ($query) "));
        return view('list', compact('data', $data)); //send record to views as data variable 
    }
    public function create()
    {
        $hospital = Hospital::all();
        return view('insert', compact('hospital', $hospital));
    }
    public function store(Request $request)
    {
        // return $request->post();
        $obj = new Patien();
        $obj->name = $request->post('p_name');
        $obj->email = $request->post('email');
        $obj->phone = $request->post('phone');
        $obj->hospital_id = $request->post('h_name');
        $obj->department_id = $request->post('d_name');
        $obj->d_and_time = date('Y-m-d h:i:s');
        $count =  Patien::get()->where('email', '=', $request->post('email'))->count();
        if ($count == 0) {
            $obj->save();
            return redirect('/')->with('success', 'Patient  registered successfully');
        } else {
            return back()->with('error', 'Email already registered');
        }
    }
}
