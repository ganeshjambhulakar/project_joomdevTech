<!DOCTYPE html>
<html lang="en">

<head>
    <title>Product Management</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

   <div class="bg-dark">
   <div class="container ">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h2 class="text-center text-dark">  Product Management </h2>
                        </div>
                        <div class="card-body">
                             <form class="form-horizontal" action="backend/add.php" method="POST" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label class="control-label col-sm-3">Product Name:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="pr_name" placeholder="Enter product name" name="pr_name" required>
                                    </div>
                                </div>
                               
                                <div class="form-group">
                                    <label class="control-label col-sm-3">Quantity:</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" id="quantity" placeholder="Enter quantity"
                                            name="quentity" required>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label col-sm-3" for="pwd">Price:</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" id="price" name="price" placeholder="Enter price" required>
                                    </div>
                                </div>
                                <div class="imgtag">
                                         <div class="form-group">
                                        <label class="control-label col-sm-3 col-12" for="pwd">Image:</label>
                                        <div class="col-sm-8 col-8 d-flex">
                                            <input type="file" class="form-control"  name="image[]" placeholder="Enter image">
                                            <button type="button" class=" btn btn-success add_image mx-5">Add </button>

                                        </div>
                                        </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-sm-3" for="pwd">Status:</label>
                                    <div class="col-sm-10">
            
                                        <select name="status" id="status" class="form-control">
                                            <option value="">Select Status</option>
                                            <option value="1">Active</option>
                                            <option value="0">Inactive</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-3">Short Description:</label>
                                    <div class="col-sm-10">
                                        <textarea name="short_desc" class="form-control" id="" rows="2"
                                            placeholder="Short Description ..."></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-3">Description:</label>
                                    <div class="col-sm-10">
                                        <textarea name="description" class="form-control" id="" rows="4"
                                            placeholder="Description ..."></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <button type="submit" class="btn btn-info">Submit</button>
                                    </div>
                                </div>
                            </form>
             
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
    </div>

   </div>
</body>
</html><?php /**PATH C:\Users\91749\laravel\project\resources\views/welcome.blade.php ENDPATH**/ ?>