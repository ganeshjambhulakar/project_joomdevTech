<!DOCTYPE html>
<html lang="en">

<head>
    <title>Hospital Management</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark"> Patient Record </h2>
                    </div>
                    @if ($message = Session::get('success'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                    @endif
                    <div class="card-body">
                        <table class="table table-bordered">
                            <button class="btn btn-info my-4">
                                 <a href="add" class="text-white">Add New Patient</a>
                                </button>
                            <div class="row d-flex">
                                <form class="form-horizontal" action="search" method="POST">
                                @CSRF    
                                <div class="col-lg-3 ">
                                        <div class="form-group">
                                                <input type="text" class="form-control" id="phone" placeholder="Enter phone" name="phone" onchange="search();" >
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                                <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" onchange="search();" >
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <button class=" btn btn-info" id="btn">Search</button>
                                        <button class="btn btn-info " ><a href="/" class="text-white">Clear</a></button>
                                    </div>
                                    </div>
                            </form>
                            
                            <tr>
                                <td style="width: 2%"> Sr.No. </td>
                                <td style="width: 15%"> Name </td>
                                <td style="width: 10%"> Email </td>
                                <td style="width: 10%"> Phone </td>
                                <td style="width: 20%"> Hospital Name </td>
                                <td style="width: 20%"> Department</td>
                                <td {{$i=1}} style="width: 20%"> Date and Time </td>
                            </tr>
                            @if(empty($data))
                                <tr><td colspan="8" class="text-center">Record Not Found</td></tr>
                            @endif   
                            @foreach($data as $arr )
                            <tr>
                                <td>{{$i++}}</td>
                                <td>{{$arr->name}}</td>
                                <td>{{$arr->email}}</td>
                                <td>{{$arr->phone}}</td>
                                <td>{{$arr->hospital_name}}</td>
                                <td>{{$arr->department_name}}</td>
                                <td>{{Date($arr->d_and_time)}}</td>
                            </tr>
                            @endforeach
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    document.getElementById('btn').setAttribute("Disabled","true");
    var phone = document.getElementById('phone');
    var email = document.getElementById('email');
   
    function search(){
        if(phone.value!="" || email.value!=""){
            document.getElementById('btn').removeAttribute("Disabled")
    } else{
        document.getElementById('btn').setAttribute("Disabled","true")

    }
    }
    // btn.setAttribute="disabled"


</script>
</html>