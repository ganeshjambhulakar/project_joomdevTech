<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Patien extends Model
{
    use HasFactory;
    protected $table = "patients";
    public $timestamps = False;
}
