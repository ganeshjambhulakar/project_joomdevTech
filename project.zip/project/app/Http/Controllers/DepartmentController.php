<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Department;

class DepartmentController extends Controller
{
    public function index(Request $req){
        return Department::get()->where('hospital_id','=',$req->post('id'));
    }
}
