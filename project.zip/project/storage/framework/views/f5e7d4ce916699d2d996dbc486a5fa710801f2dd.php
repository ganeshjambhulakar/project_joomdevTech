<!DOCTYPE html>
<html lang="en">

<head>
    <title>Hospital Management</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark"> Patient Record </h2>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <button class="btn btn-info my-4">
                                 <a href="add" class="text-white">Add New Patient</a>
                                </button>
                            <div class="row d-flex">
                                <form class="form-horizontal" action="search" method="POST">
                                <?php echo csrf_field(); ?>    
                                <div class="col-lg-3 ">
                                        <div class="form-group">
                                                <input type="text" class="form-control" id="phone" placeholder="Enter phone" name="phone" onchange="search();" >
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                                <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" onchange="search();" >
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <button class=" btn btn-info" id="btn">Search</button>
                                        <button class="btn btn-info " ><a href="/" class="text-white">Clear</a></button>
                                    </div>
                                    </div>
                            </form>
                            
                            <tr>
                                <td style="width: 2%"> Sr.No. </td>
                                <td style="width: 15%"> Name </td>
                                <td style="width: 10%"> Email </td>
                                <td style="width: 10%"> Phone </td>
                                <td style="width: 20%"> Hospital Name </td>
                                <td style="width: 20%"> Department</td>
                                <td <?php echo e($i=1); ?> style="width: 20%"> Date and Time </td>
                            </tr>
                            <?php if(empty($data)): ?>
                                <tr><td colspan="8" class="text-center">Record Not Found</td></tr>
                            <?php endif; ?>   
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($arr->name); ?></td>
                                <td><?php echo e($arr->email); ?></td>
                                <td><?php echo e($arr->phone); ?></td>
                                <td><?php echo e($arr->hospital_name); ?></td>
                                <td><?php echo e($arr->department_name); ?></td>
                                <td><?php echo e(Date($arr->d_and_time)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    document.getElementById('btn').setAttribute("Disabled","true");
    var phone = document.getElementById('phone');
    var email = document.getElementById('email');
   
    function search(){
        if(phone.value!="" || email.value!=""){
            document.getElementById('btn').removeAttribute("Disabled")
    } else{
        document.getElementById('btn').setAttribute("Disabled","true")

    }
    }
    // btn.setAttribute="disabled"


</script>
</html><?php /**PATH C:\Users\91749\laravel\project\resources\views/list.blade.php ENDPATH**/ ?>