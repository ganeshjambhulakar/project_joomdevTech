<!DOCTYPE html>
<html lang="en">

<head>
    <title>Product Management</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

    <div class="bg-dark">
        <div class="container ">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="card mt-5">
                            <div class="card-header">
                                <h2 class="text-center text-dark"> Patient Management </h2>
                                <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                                <?php endif; ?>

                            </div>
                            <div class="card-body">
                                <form class="form-horizontal" action="store" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Name:</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" id="p_name" placeholder="Enter Patien Name" name="p_name" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Email:</label>
                                        <div class="col-sm-10">
                                            <input type="email" class="form-control" id="email" placeholder="Enter Email" name="email" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label col-sm-3" for="pwd">Phone:</label>
                                        <div class="col-sm-10">
                                            <input type="number" class="form-control" id="phone" name="phone" placeholder="Enter Phone Number" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label col-sm-3" for="pwd">Hospital Name:</label>
                                        <div class="col-sm-10">
                                            <select name="h_name" id="h_name" onchange="department();" class="form-control" required>
                                                <option value="">Select Hospital Name</option>
                                                <?php $__currentLoopData = $hospital; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($arr->hospital_id); ?>"><?php echo e($arr->hospital_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group"  id="dept">
                                        <label class="control-label col-sm-3" for="pwd">Department:</label>
                                        <div class="col-sm-10">
                                            <select name="d_name" id="d_name" class="form-control">
                                               
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-offset-2 col-sm-10">
                                            <button type="submit" class="btn btn-info">Submit</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
</body>
<script>
         document.getElementById('dept').style.display="none";  

function department() {
        var msg = [];
        var option ;
        var hospital = $('#h_name').val();
        if (hospital != "") {
            document.getElementById('dept').style.display="block";  
            $.ajax({
                type: "POST",
                url: 'api/department', // Not sure what to add as URL here
                data: {
                    id: hospital
                }
            }).done(function(msg) {
                let option=" ";
                for( var index in msg ){
                    var currentObject = msg[ index ];
                      option +="<option value='"+currentObject.department_id+"'>"+currentObject.department_name+"</option> "  
                    }
                    document.getElementById('d_name').innerHTML=option;  
            });

        } else {
            document.getElementById('dept').style.display="none";  
        }
    }
</script>

</html><?php /**PATH C:\Users\91749\laravel\project\resources\views/insert.blade.php ENDPATH**/ ?>